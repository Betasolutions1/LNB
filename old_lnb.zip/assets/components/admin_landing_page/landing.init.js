(function($)
{

	$("#owl-landing").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	singleItem:true,
      	autoPlay : 5000,
      	transitionStyle: "backSlide"
      	// transitionStyle: "goDown"
	});

})(jQuery);