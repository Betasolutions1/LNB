(function($){

	$(window).stellar({
		horizontalScrolling: false,
		verticalScrolling: true,
	    verticalOffset: 0,
	    horizontalOffset: 0
	});

})(jQuery);